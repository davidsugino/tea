```{eval-rst}
:mod:`tea.msg` Module
=====================

.. automodule:: tea.msg
    :members:

.. automodule:: tea.msg.mail
    :members:
```