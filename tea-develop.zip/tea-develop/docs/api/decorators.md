```{eval-rst}
:mod:`tea.decorators` Module
============================

.. automodule:: tea.decorators
    :members:
```