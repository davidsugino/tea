# Tea api documentation

```{toctree}
---
maxdepth: 3
---

ctx.md
decorators.md
dsa.md
errors.md
logger.md
msg.md
process.md
serde.md
shell.md
timestamp.md
utils.md
```
