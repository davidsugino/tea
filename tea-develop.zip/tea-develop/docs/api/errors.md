```{eval-rst}
:mod:`tea.errors` Module
========================

.. automodule:: tea.errors
    :members:
```