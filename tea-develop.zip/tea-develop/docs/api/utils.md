```{eval-rst}
:mod:`tea.utils` Module
=======================

.. automodule:: tea.utils
    :members:

.. automodule:: tea.utils.encoding
    :members:

.. automodule:: tea.utils.html
    :members:
```
