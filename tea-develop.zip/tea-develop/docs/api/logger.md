```{eval-rst}
:mod:`tea.logger` Module
========================

.. automodule:: tea.logger
    :members:
```