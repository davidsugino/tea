```{eval-rst}
:mod:`tea.dsa` Module
=====================

.. automodule:: tea.dsa
    :members:

.. automodule:: tea.dsa.config
    :members:

.. automodule:: tea.dsa.plugin
    :members:

.. automodule:: tea.dsa.singleton
    :members:
```