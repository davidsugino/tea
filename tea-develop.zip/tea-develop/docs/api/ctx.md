```{eval-rst}
:mod:`tea.ctx` Module
=====================

.. automodule:: tea.ctx
    :members:
```