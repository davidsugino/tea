```{eval-rst}
:mod:`tea.shell` Module
=======================

.. automodule:: tea.shell
    :members:
```