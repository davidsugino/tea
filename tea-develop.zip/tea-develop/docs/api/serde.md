```{eval-rst}
:mod:`tea.serde` Module
=========================

.. automodule:: tea.serde
    :members:
```