# Welcome to the Tea Documentation

This documentation details how to use the `tea` project. 


## API Documentation

```{toctree}
---
maxdepth: 3
---

api/index.md
```

## Indices and tables

* {ref}`genindex`
* {ref}`modindex`
* {ref}`search`
