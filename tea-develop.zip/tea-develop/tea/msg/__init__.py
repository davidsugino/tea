__all__ = ["send_mail", "send_mass_mail"]

from tea.msg.mail import send_mail, send_mass_mail
